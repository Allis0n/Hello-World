public class StringBufferDemo {

 public static void main(String[] args) {
  
  StringBuffer sb = new StringBuilder();

  sb.append("My name is");

  sb.append("Allison.");

  System.out.println(sb.toString());//My name is Allison.

  System.out.println(sb.length());//19

  System.out.println(sb.indexOf("a"));//4
  
  System.out.println(sb.indexOf("A"));//11

  sb.insert(sb.indexOf("star"), "new ");

  System.out.println(sb.toString());//This is a new star

  System.out.println(sb.reverse().toString());//rats wen a si sihT

 }

}
/*其他方法StringBuffer*/
/* http://tw.gitbook.net/java/java_string_buffer.html */
